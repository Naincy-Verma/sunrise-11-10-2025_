<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class About extends Model
{
    //
    protected $fillable = [
        'image',
         'image_small1', 
         'image_small2',
        'heading',
        'description',
        'slug'
    ];

    public $timestamps = true;
    protected $table = "abouts";
}
