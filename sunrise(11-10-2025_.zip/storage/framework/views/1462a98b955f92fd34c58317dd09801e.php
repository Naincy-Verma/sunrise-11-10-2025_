 <?php $__env->startSection('css'); ?> <style>
  .doctor-detail-page {
    padding: 50px 0px;
  }

  .content-section {
    background: white;
    border-radius: 5px;
    box-shadow: 0 1px 4px 0 rgba(0, 0, 0, .25);
    margin-bottom: 30px;
    overflow: hidden;
  }

  .brief-header {
    background: linear-gradient(135deg, #00416f 0%, #007f97 100%);
    color: white;
    padding: 10px 20px;
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 20px;
  }

  .section-content {
    padding: 0px 20px;
  }

  .achievements-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
    margin: 30px 0;
  }

  .achievement-card {
    background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
    border: 1px solid #bae6fd;
    border-radius: 5px;
    padding: 15px;
    transition: all 0.3s ease;
    box-shadow: 0 1px 4px 0 rgba(0, 0, 0, .25);
  }

  .achievement-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 1px 4px 0 rgba(0, 0, 0, .25);
  }

  .achievement-title {
    font-weight: 700;
    color: #003366;
    margin-bottom: 10px;
    font-size: 1.1rem;
  }

  .achievement-desc {
    color: #4b5563;
    line-height: 1.6;
  }

  .specialties-list {
    list-style: none;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 15px;
  }

  .specialties-list li {
    background: #f8fafc;
    border-radius: 10px;
    padding: 15px 20px;
    transition: all 0.3s ease;
    position: relative;
    padding-left: 50px;
    box-shadow: 0 1px 4px 0 rgba(0, 0, 0, .25);
  }

  .specialties-list li::before {
    content: '✓';
    position: absolute;
    left: 20px;
    top: 28%;
    background: #0097a7;
    color: white;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.8rem;
    font-weight: bold;
  }

  .specialties-list li:hover {
    border-color: #3b82f6;
    background: #f0f9ff;
    transform: translateX(5px);
  }

  .training-programs {
    background: #f8fafc;
    border-radius: 15px;
    padding: 30px;
    margin: 30px 0;
  }

  .program-item {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 15px;
    padding: 15px;
    background: white;
    border-radius: 10px;
    border-left: 4px solid #003366;
  }

  .program-number {
    background: #003366;
    color: white;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    flex-shrink: 0;
  }

  .program-details {
    flex: 1;
  }

  .program-name {
    font-weight: 600;
    color: #003366;
    margin-bottom: 5px;
  }

  .program-duration {
    color: #6b7280;
    font-size: 0.9rem;
  }

  .highlight-box {
    background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
    border: 2px solid #f59e0b;
    border-radius: 5px;
    padding: 10px 15px;
    margin: 30px 0;
  }

  .highlight-title {
    font-size: 1.3rem;
    font-weight: 700;
    color: #92400e;
    margin-bottom: 10px;
  }

  .records-section {
    border: 2px solid #0097a7;
    border-radius: 15px;
    padding: 30px;
    margin: 30px 0;
  }

  .record-item {
    display: flex;
    align-items: flex-start;
    gap: 15px;
    margin-bottom: 20px;
    padding: 10px 15px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 1px 4px 0 rgba(0, 0, 0, .25);
  }

  .record-icon {
    background: #0097a7;
    color: white;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    flex-shrink: 0;
  }

  .record-content {
    flex: 1;
  }

  .record-title {
    font-weight: 700;
    color: #003366;
    margin-bottom: 8px;
    font-size: 1.1rem;
  }

  @media (max-width: 768px) {
    .doctor-name {
      font-size: 2rem;
    }

    .profile-header {
      flex-direction: column;
      text-align: center;
      padding: 30px 20px;
    }

    .doctor-image {
      width: 150px;
      height: 150px;
    }

    .section-content,
    .section-header {
      padding: 20px;
    }

    .achievements-grid {
      grid-template-columns: 1fr;
    }

    .specialties-list {
      grid-template-columns: 1fr;
    }

    .container {
      margin-top: -30px;
    }
  }

  .experience-highlights {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin: 30px 0;
  }

  .experience-card {
    background: white;
    border: 2px solid #e5e7eb;
    border-radius: 12px;
    padding: 25px;
    text-align: center;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
  }

  .experience-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%);
  }

  .experience-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.12);
    border-color: #3b82f6;
  }

  .experience-number {
    font-size: 2.5rem;
    font-weight: 800;
    color: #1e40af;
    margin-bottom: 10px;
    display: block;
  }

  .experience-label {
    color: #6b7280;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    font-size: 0.9rem;
  }

  .doctor-section::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: #ecf5fb;
    z-index: -1;
  }
</style> 
<?php $__env->stopSection(); ?>
 <?php $__env->startSection('content'); ?> 
    <section class="hero-section">
    <div class="container container-custom">
        <div class="row justify-content-center">
        <div class="col-lg-12">
            <h5 class="mb-3"><?php echo e($doctor->name); ?></h5>
            <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                <a href="<?php echo e(url('/')); ?>">Home</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($doctor->name); ?></li>
            </ol>
            </nav>
        </div>
        </div>
    </div>
    </section>
    <section>
    <div class="container">
        <div class="row align-items-center">
        <!-- Left: Image -->
        <div class="col-lg-5 mb-5 mb-lg-0">
            <div class="doctor-img">
            <img src="<?php echo e(asset('admin-assets/images/admin-image/doctors/' . $doctor->profile_image)); ?>" alt="<?php echo e($doctor->name); ?>">
            </div>
        </div>
        <!-- Right: Info -->
        <div class="col-lg-7 doctor-details">
            <h5><?php echo e($doctor->designation); ?></h5>
            <h2><?php echo e($doctor->name); ?></h2>
            <p><?php echo e($doctor->description); ?></p>
            <p>
            <strong>Designation:</strong> <?php echo e($doctor->designation); ?>

            </p>
            <p>
            <strong>Areas of Expertise:</strong> <?php echo e($doctor->speciality->title ?? '—'); ?>

            </p>
            <p>
            <strong>Qualification:</strong> <?php echo e($doctor->qualification); ?>

            </p>
        </div>
        </div>
    </div>
    </section>
    <div class="doctor-detail-page">
    <div class="container">
        <div class="content-section">
        <div class="brief-header"><?php echo e($doctor->brief_profile_heading); ?></div>
          <div class="section-content">
              <p> <?php echo $doctor->brief_profile_description; ?> </p>
              <div class="row">
              <div class="col-lg-7 col-md-7">
                  <img src="<?php echo e(asset('admin-assets/images/admin-image/doctors/' . $doctor->brief_profile_image)); ?>" width="100%" alt="Patient Image">
              </div>
              <div class="col-lg-5 col-md-5"></div>
              </div>
              
                <?php if(!empty($doctor->brief_notable_records)): ?>
                <div class="highlight-box">
                    <p class="highlight-text"><?php echo $doctor->brief_notable_records; ?></p>
                </div> 
                <?php endif; ?>

                
                <?php if(!empty($doctor->brief_metrics) && is_array($doctor->brief_metrics)): ?>
                    <div class="experience-highlights">
                        <?php $__currentLoopData = $doctor->brief_metrics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!empty($metric['value']) || !empty($metric['label'])): ?>
                                <div class="experience-card">
                                    <span class="experience-number"><?php echo e($metric['value'] ?? ''); ?></span>
                                    <span class="experience-label"><?php echo e($metric['label'] ?? ''); ?></span>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>


          </div>
        </div>
        <!-- Professional Achievements -->
        <div class="content-section">
        <div class="brief-header"><?php echo e($doctor->professional_heading); ?></div>
        <div class="section-content">
              <?php 
              $profDesc = $doctor->professional_description; if (is_string($profDesc)) { $profDesc = json_decode($profDesc, true); }
              ?>
               <?php if(!empty($profDesc) && is_array($profDesc)): ?>
          <div class="achievements-grid">
            <?php $__currentLoopData = $profDesc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achievement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <!-- <pre><?php echo e(print_r($achievement, true)); ?></pre>  -->
              <div class="achievement-card">
                <?php if(is_array($achievement)): ?>
                  <div class="achievement-title"><?php echo e($achievement['label'] ?? 'Achievement'); ?></div>
                  <?php if(!empty($achievement['value'])): ?>
                    <p class="achievement-desc"><?php echo e($achievement['value']); ?></p>
                  <?php endif; ?>
                <?php else: ?>
                  <div class="achievement-title"><?php echo e($achievement); ?></div>
                <?php endif; ?>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
         
<?php if(!empty($doctor->training_heading)): ?> 
<div class="training-programs mt-5">
    <h3 style="color:#003366; margin-bottom: 25px; font-size: 1.3rem;">
        <?php echo e($doctor->training_heading); ?>

    </h3>

    <!-- <?php
        $trainingPrograms = $doctor->training_description;
        if (is_string($trainingPrograms)) {
            $trainingPrograms = json_decode($trainingPrograms, true);
        }
    ?> -->

    
    <?php if(!empty($trainingPrograms) && is_array($trainingPrograms)): ?>
        <?php $__currentLoopData = $trainingPrograms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <!-- <pre><?php echo e(print_r($program, true)); ?></pre> -->
            <?php if(is_array($program)): ?>
                <div class="program-item">
                    <div class="program-number"><?php echo e($index + 1); ?></div>
                    <div class="program-details">
                        <div class="program-name"><?php echo e($program['label'] ?? $program['value'] ?? ''); ?></div>
                        <?php if(!empty($program['value'])): ?> 
                            <div class="program-duration"><?php echo e($program['value']); ?></div> 
                        <?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="program-item">
                    <div class="program-number"><?php echo e($index + 1); ?></div>
                    <div class="program-details">
                        <div class="program-name"><?php echo e($program); ?></div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div> 
<?php endif; ?>


        
        <?php if(!empty($doctor->training_record)): ?>
            <div class="highlight-box mt-4">
                <p class="highlight-text"><?php echo $doctor->training_record; ?></p>
            </div> 
        <?php endif; ?>

        </div>
        </div>
        <!-- Specialized Procedures & Records -->
          <div class="content-section">
              <div class="brief-header"><?php echo e($doctor->specialized_heading); ?></div>
              <div class="section-content">
                  <div class="records-section">
                      <h3 style="color: #003366; margin-bottom: 25px; font-size: 1.3rem;">
                          <?php echo e($doctor->specialized_subheading); ?>

                      </h3>

                      <?php
                          // Decode JSON if necessary
                          $specializedData = $doctor->specialized_description;
                          if (is_string($specializedData)) {
                              $specializedData = json_decode($specializedData, true);
                          }
                      ?>

                      
                      <?php if(!empty($specializedData) && is_array($specializedData)): ?>
                      <!-- <pre><?php echo e(print_r($specializedData, true)); ?></pre> -->
            <?php $__currentLoopData = $specializedData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if(is_array($record)): ?>
                <div class="record-item">
                  <div class="record-icon"><?php echo e($index + 1); ?></div>
                  <div class="record-content">
                    <div class="record-title"><?php echo e($record['label'] ?? $record['value'] ?? ''); ?></div>
                    <?php if(!empty($record['value']) || !empty($record['value'])): ?>
                      <p class="record-desc"><?php echo e($record['value'] ?? $record['value']); ?></p>
                    <?php endif; ?>
                  </div>
                </div>
              <?php else: ?>
                <div class="record-item">
                  <div class="record-icon"><?php echo e($index + 1); ?></div>
                  <div class="record-content">
                    <div class="record-title"><?php echo e($record); ?></div>
                  </div>
                </div>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
            <p>—</p>
          <?php endif; ?>
                  </div>
              </div>
          </div>

        <!-- Areas of Specialization -->
        <div class="content-section">
        <div class="brief-header">Areas of Specialization</div>
        <div class="section-content">
            <ul class="specialties-list"> <?php if(is_array($doctor->areas_of_specialization)): ?> <ul class="specialties-list"> <?php $__currentLoopData = $doctor->areas_of_specialization; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <li><?php echo e($specialization); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> </ul> <?php endif; ?> </ul>
        </div>
        </div>
        <!-- Professional Contributions -->
        <div class="content-section">
        <div class="brief-header"><?php echo e($doctor->contributions_heading); ?></div>
        <div class="section-content">
            <p><?php echo $doctor->contributions_description; ?></p>
            <div class="highlight-box">
            <p class="highlight-text"><?php echo $doctor->latest_achievement; ?></p>
            </div>
        </div>
        </div>
    </div>
    </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sunrise(11-10-2025_\resources\views/pages/team-details.blade.php ENDPATH**/ ?>