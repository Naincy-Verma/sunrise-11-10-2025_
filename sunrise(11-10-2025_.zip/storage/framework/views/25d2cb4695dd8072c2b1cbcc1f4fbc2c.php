

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="card">
    <div class="card-header d-flex justify-content-between">
      <h4 class="card-title mb-0">Quick Enquiries</h4>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>No.</th>
              <th>Name</th>
              <th>Mobile Number</th>
              <th>Preferred Time Slot</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($index + 1); ?></td>
              <td><?php echo e($enquiry->name); ?></td>
              <td><?php echo e($enquiry->mobile_number); ?></td>
              <td>
                    <?php if($enquiry->timeSlot): ?>
                        <?php echo e(\Carbon\Carbon::parse($enquiry->timeSlot->start_time)->format('g:i A')); ?>

                        -
                        <?php echo e(\Carbon\Carbon::parse($enquiry->timeSlot->end_time)->format('g:i A')); ?>

                    <?php else: ?>
                        N/A
                    <?php endif; ?>
              </td>


              <td><?php echo e($enquiry->created_at->format('d M Y, h:i A')); ?></td>
              <td>
                <a href="<?php echo e(route('admin.quick-enquiries.show', $enquiry->id)); ?>" class="btn btn-secondary btn-sm">
                  <i class="fas fa-eye"></i>
                </a>
                <form action="<?php echo e(route('admin.quick-enquiries.destroy', $enquiry->id)); ?>" method="POST" style="display:inline;" class="delete-form">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="button" class="btn btn-danger btn-sm delete-btn" data-title="<?php echo e($enquiry->name); ?>">
                    <i class="fas fa-trash-alt"></i>
                  </button>
                </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="6" class="text-center text-muted">No enquiries found.</td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const deleteButtons = document.querySelectorAll('.delete-btn');

    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const form = this.closest('.delete-form');
            const title = this.getAttribute('data-title');

            Swal.fire({
                title: 'Are you sure?',
                text: `You are about to delete enquiry from "${title}". This action cannot be undone.`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sunrise(11-10-2025_\resources\views/admin/pages/quick_enquiry/index.blade.php ENDPATH**/ ?>