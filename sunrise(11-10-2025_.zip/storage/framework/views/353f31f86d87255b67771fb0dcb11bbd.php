<?php $__env->startSection('css'); ?>
<style>
    .btn-link-view {
        font-size: 14px;
        font-weight: 600;
        color: #ffffff;
        text-decoration: none;
        position: relative;
        padding-bottom: 3px;
        background: #0097a7;
        transition: color 0.3s ease;
        border-color: #0097a7;
        border-radius: 10px;
    }

    .btn-link-view::after {
        content: "";
        position: absolute;
        left: 0;
        bottom: 0;
        width: 0;
        height: 2px;
        background: #0097a7;
        transition: width 0.3s ease;
    }

    .btn-link-view:hover {
        color: var(--bs-btn-hover-color);
        background-color: #0097a7;
        border-color: #0097a7;
    }

    .btn-check:checked+.btn,
    .btn.active,
    .btn.show,
    .btn:first-child:active,
    :not(.btn-check)+.btn:active {
        color: var(--bs-btn-active-color);
        background-color: #0097a7;
        border-color: #0097a7;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Carousel Section -->
    <section class="carousel-section">
        <!-- Swiper -->
        <div class="swiper myCarouselSwiper">
            <?php if($type['code'] == 200): ?>
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img src="<?php echo e(asset('assets/images/slider/1.webp')); ?>" alt="Hospital Image 1">
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php echo e(asset('assets/images/slider/2.webp')); ?>" alt="Hospital Image 2">
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php echo e(asset('assets/images/slider/3.webp')); ?>" alt="Hospital Image 3">
                    </div>
                </div>
            <?php elseif($type['code'] == 201): ?>
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img src="<?php echo e(asset('assets/images/slider/mobile3.webp')); ?>" alt="Hospital Image 1">
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php echo e(asset('assets/images/slider/mobile2.webp')); ?>" alt="Hospital Image 2">
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php echo e(asset('assets/images/slider/mobile1.webp')); ?>" alt="Hospital Image 3">
                    </div>
                </div>
            <?php endif; ?>
            <!-- Pagination -->
            <div class="swiper-pagination"></div>

            <!-- Navigation -->
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </section>

    <!-- Our Specialties -->
    <section class="specialties-section text-center py-5">
        <div class="container">
            <h2 class="fw-bold mb-3">Our Specialties</h2>
            <p class="mb-5">
                Explore our wide range of specialties and find the right healthcare
                service for your needs.
            </p>

            <div class="row row-cols-2 row-cols-md-3 row-cols-lg-5 g-4">
                <?php $__currentLoopData = $specialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col">
                        <a href="<?php echo e(url('specialities', $speciality->slug)); ?>">
                            <div class="card h-100 shadow-sm border-0 rounded-4">
                                <div class="card-body d-flex flex-column align-items-center">
                                    <div class="rounded-3 d-flex align-items-center justify-content-center mb-3"
                                        style="width:70px;height:70px;font-size:32px;color:#1664c0;">
                                        <img src="<?php echo e(asset($speciality->icon)); ?>" width="110px" alt="<?php echo e($speciality->title); ?>" />
                                    </div>
                                    <h6 class="fw-semibold"><?php echo e($speciality->title); ?></h6>
                                </div>
                            </div>
                        </a>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section class="intro-content">
        <div class="container">
            <div class="row">
                <!-- Right Side: Content -->
                <div class="col-lg-6">
                    <h1 class="fw-bold mb-3">Compassionate Care, Advanced Treatment, Trusted Expertise.</h1>
                    <h2>
                        About Sunrise Hospital
                    </h2>
                    <p class="mb-3">
                        <b>Sunrise Hospital</b>, Delhi NCR, is a trusted multispeciality and gynecology hospital offering
                        expert care in pregnancy, IVF, pediatrics, and advanced laparoscopic surgery.
                    </p>
                    <p class="mb-3">
                        Known as one of the best maternity and IVF hospitals in Delhi, we specialize in normal deliveries,
                        C-sections, high-risk pregnancies, fertility treatments, and minimally invasive gynecology
                        procedures.
                    </p>
                    <p class="mb-3">With modern facilities, experienced doctors, and compassionate care, Sunrise Hospital is
                        dedicated to ensuring better health for women, children, and families.</p>
                </div>
                <!-- Left Side: Image -->
                <div class="col-lg-6 mb-4 mb-lg-0 text-center">
                    <div class="about-image">
                        <img src="<?php echo e(asset('assets/images/home-page/about-sunrise.webp')); ?>"
                            alt="Best Gynecologist Hospital in Delhi NCR" class="img-fluid" width="340px">
                    </div>
                </div>
            </div>
        </div>
    </section>

        <!-- Book Your appointment -->
    <section class="appointment-section">
        <h2>Book Your Appointment Now</h2>

        <form class="appointment-form" action="<?php echo e(route('appointments.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
             <input type="hidden" name="source" value="index-page">

            <div class="row g-3">

                <div class="col-md-6">
                    <div class="form-group">
                        <i class="bi bi-person"></i>
                        <input type="text" class="form-control" placeholder="Name" name="name" required  oninput="this.value = this.value.replace(/[^A-Za-z\s]/g,'');">
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <i class="bi bi-envelope"></i>
                        <input type="email" class="form-control" placeholder="Email" name="email" required>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <i class="bi bi-telephone"></i>
                        <input type="tel" class="form-control" placeholder="Phone Number" name="phone" required required maxlength="13" oninput="this.value = this.value.replace(/[^0-9]/g,'');">
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <i class="bi bi-hospital"></i>
                        <select class="form-control" name="speciality" required>
                             <option value="">Select Speciality</option>
                            <?php $__currentLoopData = $specialities_form; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($speciality->id); ?>"><?php echo e($speciality->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <!-- Captcha full width -->
                <div class="col-12">
                    <div class="captcha-box">
                        <div class="captcha-text" id="captcha">AB12C</div>
                        <input type="text" class="captcha-input" placeholder="Enter Captcha" id="captcha-input" required>
                        <button type="button" class="captcha-refresh" onclick="generateCaptcha()">
                            <i class="bi bi-arrow-clockwise"></i>
                        </button>
                    </div>
                </div>

                <div class="col-12">
                    <button type="submit">Book an Appointment</button>
                </div>

            </div>
        </form>
    </section>

    <!-- About Dr. Nikita -->
    <section class="doctor-section">
        <div class="container">
            <div class="row align-items-center">
                <!-- Left Side: Doctor Image -->
                <div class="col-lg-5 mb-5 mb-lg-0">
                    <div class="doctor-img">
                        <img src="<?php echo e(asset('assets/images/home-page/nikita.webp')); ?>" alt="Doctor" />
                        <div class="drexperience-badge">
                            <span>20+</span>
                            Years Experienced
                        </div>
                    </div>
                </div>

                <!-- Right Side: Doctor Info -->
                <div class="col-lg-7 doctor-details">
                    <h5>World Renowned Gynae Laparoscopic Surgeon</h5>
                    <h2>DR. NIKITA TREHAN</h2>
                    <p>
                        Consult with internationally acclaimed surgeon having record-breaking
                        achievements in laparoscopic surgeries.
                    </p>

                    <h6 class="skills-title">Key Achievements</h6>
                    <ul class="skills-list">
                        <li><i class="fa-solid fa-check"></i> Record for the largest fibroid removed laparoscopically of
                            6.5 KGS</li>
                        <li><i class="fa-solid fa-check"></i> Record for the oldest patient operated at 107 years old</li>
                        <li><i class="fa-solid fa-check"></i> Record for the largest Uterus removed laparoscopically of
                            9.5kg</li>
                        <li>
                            <i class="fa-solid fa-check"></i> Achieves Medical Milestone With 127-Day Delayed Twin Delivery
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>




    
        
            
                
                
                    
                        
                            
                            
                                
                                
                                
                            
                                
                                
                                
                            
                        
                            
                            
                        
                            
                            
                        
                    

                
                
                    
                        
                        
                        
                        
                        
                        
                    
                
            
        
    <!-- About SEction End -->

    
        
            

                
                
                    

                    
                    
                        
                        
                             
                                
                                
                                
                            
                        
                             
                                
                                
                            
                        

                    
                    
                        
                         
                            
                                
                                    
                                        
                                            
                                            
                                        
                                    
                                        
                                            
                                            
                                        
                                    
                                        
                                            
                                            
                                        
                                    
                                        
                                            
                                            
                                        
                                    
                                        
                                            
                                            
                                        
                                    

                                
                                    
                                        
                                            
                                            
                                        
                                    
                                        
                                            
                                            
                                        
                                    
                                        
                                            
                                            
                                        
                                    
                                        
                                            
                                            
                                        
                                    
                                        
                                            
                                            
                                        
                                    
                                

                             
                                
                                
                            

                        
                        
                            
                                
                                    
                                        
                                            
                                            
                                        
                                     
                                        
                                            
                                            
                                        
                                    
                                
                                     
                                        
                                            
                                            
                                        
                                     
                                        
                                            
                                            
                                        
                                    
                                
                             
                                
                                
                            
                        
                    

                
                
                    
                        
                        
                            
                            
                             
                            
                        
                    
                
            
        

    
        
            
                
                
                    
                        
                             
                            
                        
                             
                            
                        
                             
                            
                        
                    

                
                
                    
                    
                        
                        
                    
                        
                        

                    
                        
                            
                                
                                
                                    
                                    
                                        
                                        
                                    
                                
                            
                        
                            
                                
                                
                                    
                                    
                                        
                                        
                                    
                                
                            
                        
                            
                                
                                
                                    
                                    
                                        
                                        
                                    
                                
                            
                        
                            
                                
                                
                                    
                                    
                                        
                                        
                                    
                                
                            
                        
                    
                
            
        

    <!-- Doctors Section -->
    <div class="container my-5">
        <h2 class="text-center mb-4">Meet Our Trusted Specialists</h2>
        <!-- Swiper -->
        <div class="swiper mySwiper">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Doctor Card 1 -->
                <div class="swiper-slide">
                    <div class="card doctor-card">
                        <span class="experience-badge">1<?php echo e($doctor->experience); ?></span>
                         <img src="<?php echo e(asset('admin-assets/images/admin-image/doctors/' . $doctor->profile_image)); ?>" alt="<?php echo e($doctor->name); ?>" />
                        <div class="doctor-info">
                            <h5><?php echo e($doctor->name); ?></h5>
                            <p><?php echo e($doctor->qualification); ?></p>
                            <p class="text-success"><?php echo e($doctor->speciality); ?></p>
                            <div class="doctor-actions d-flex">
                                <!-- Appointment Button -->
                                <a href="<?php echo e($doctor->appointment_url ?? '#'); ?>" 
                                class="btn btn-appointment flex-fill me-2" 
                                data-bs-toggle="tooltip" 
                                title="Book Appointment">
                                    <i class="fa-solid fa-calendar-check"></i>
                                </a>

                                <!-- Profile Button: Only show if profile_url exists -->
                                <?php if(!empty($doctor->profile_url)): ?>
                                    <a href="<?php echo e(route('doctor-detail', ['slug' => $doctor->profile_url])); ?>" 
                                    class="btn btn-profile flex-fill" 
                                    data-bs-toggle="tooltip" 
                                    title="View Profile">
                                        <i class="fa-solid fa-user"></i>
                                    </a>
                                <?php else: ?>
                                    <a href="#" class="btn btn-profile flex-fill disabled" 
                                    data-bs-toggle="tooltip" 
                                    title="Profile not available">
                                        <i class="fa-solid fa-user"></i>
                                    </a>
                                <?php endif; ?>

                            </div>

                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </div>
            <!-- Swiper Controls -->
            <div class="swiper-pagination"></div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
        <!-- View More Button -->
        <div class="text-center mt-4">
            <a href="<?php echo e(url('doctors')); ?>" class="btn btn-primary btn-sm btn-link-view">View All</a>
        </div>
    </div>

    <section class="choose-section">
        <div class="container">
            <div class="row align-items-center">
                <!-- Left Content -->
                <div class="col-lg-6" data-aos="fade-right">
                    <h6>Why Choose Us</h6>
                    <h2>
                        Why Choose Sunrise Hospital, Delhi
                    </h2>
                    <p>
                        At Sunrise Hospital, South Delhi, we are committed to providing world-class gynecology, maternity,
                        IVF, and laparoscopic treatments with a patient-first approach. Our hospital combines modern
                        technology, expert doctors, and affordable care, making us one of the most trusted healthcare
                        destinations in Delhi NCR.
                    </p>

                    <div class="timeline">
                        <div class="step" data-aos="fade-up" data-aos-delay="100">
                            <div class="circle">1</div>
                            <div>
                                <h3>Modern Technology</h3>
                                <p>
                                    We use advanced laparoscopic and minimally invasive equipment, ensuring safer surgeries,
                                    faster recovery, and precision-driven treatments. Recognized as a Center of Excellence
                                    for Laparoscopic & Endoscopic Surgeries in Asia, we are equipped with state-of-the-art
                                    facilities for women’s health and fertility care.
                                </p>
                            </div>
                        </div>

                        <div class="step" data-aos="fade-up" data-aos-delay="200">
                            <div class="circle">2</div>
                            <div>
                                <h3>Professional Doctors</h3>
                                <p>
                                    Our team includes internationally acclaimed gynecologists, laparoscopic surgeons, and
                                    IVF specialists with decades of experience. Patients across India and abroad trust our
                                    doctors for their expertise, compassionate care, and successful treatment outcomes.
                                </p>
                            </div>
                        </div>

                        <div class="step" data-aos="fade-up" data-aos-delay="300">
                            <div class="circle">3</div>
                            <div>
                                <h3>Affordable Price</h3>
                                <p>
                                    We believe quality healthcare should be accessible to everyone. Sunrise Hospital offers
                                    cost-effective gynecology, maternity, and IVF treatments in Delhi, without compromising
                                    on safety, technology, or patient comfort.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Right Image -->
                <div class="col-lg-6 choose-image" data-aos="zoom-in">
                    <img src="<?php echo e(asset('assets/images/home-page/why-choose.webp')); ?>" alt="Doctors" />
                    <div class="service-box" data-aos="flip-left">
                        <i class="bi bi-telephone-fill call-icon"></i>
                        <div>
                            <h6>Book Appointment</h6>
                            <p><a href="tel:+919800001900">+91 9800001900</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="patient-testimonial-slider">
        <div class="container">
            <div class="text-center">
                <h2>Our Patients, Their Words</h2>
            </div>
          <div class="swiper PatientTestimonialSwiper">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide">
                        <div class="instagram-card">
                            <iframe 
                                src="https://www.instagram.com/reel/DOsjkQAksf1/embed" 
                                width="400" 
                                height="480" 
                                frameborder="0" 
                                scrolling="no" 
                                allowtransparency="true">
                            </iframe>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="text-center mt-4">
                <a href="<?php echo e(url('patient-testimonial')); ?>" class="btn btn-primary btn-sm btn-link-view">View All</a>
            </div>
        </div>
    </section>

    <section class="rare-section">
        <div class="container">
            <div class="text-center mb-5">
                <h2>Rare Cases & Medical Breakthroughs</h2>
                <p>
                    At Sunrise Hospital, South Delhi, our internationally trained doctors handle rare medical cases and
                    deliver innovative gynecology, IVF, and minimally invasive treatments. Patients from India and abroad
                    trust us for cutting-edge healthcare solutions.
                </p>
            </div>

            <!-- Swiper -->
            <div class="swiper myRareSwiper">
                <div class="swiper-wrapper">
                    <?php $__currentLoopData = $cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $case): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <div class="card rare-card">
                                <img src="<?php echo e(asset('admin-assets/images/admin-image/rare-cases/' . $case->image)); ?>"
                                    alt="<?php echo e($case->title); ?>" />
                                <div class="rare-card-body">
                                    <h5 class="truncate-heading"><?php echo e($case->title); ?></h5>
                                    <p class="truncate-text"><?php echo e($case->short_description); ?></p>
                                    <a href="<?php echo e($case->source); ?>" target="_blank" class="btn-read">Read More</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Swiper Controls -->
                <div class="swiper-pagination"></div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>

            <!-- View More Button -->
            <div class="text-center mt-4">
                <a href="<?php echo e(url('rare_case')); ?>" class="btn btn-primary btn-sm btn-link-view">View All</a>
            </div>
        </div>
    </section>


    <!-- Events Section -->
    <section class="events-section py-5">
        <div class="container">
            <div class="text-center">
                <h2>Sunrise Hospital: Where Care Meets Community</h2>
                <p>
                    Stay informed about upcoming health events, workshops, and awareness programs at Sunrise Hospital, South
                    Delhi. Join our expert-led sessions on gynecology, IVF, maternity, pediatrics, and minimally invasive
                    surgeries to gain valuable insights and enhance your health knowledge. Participate to stay proactive
                    about your wellbeing.
                </p>
            </div>

            <!-- Swiper -->
            <div class="swiper myEventSwiper"> <!-- Add this container -->
                <div class="swiper-wrapper">
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <div class="card rare-card">
                                <img src="<?php echo e(asset('admin-assets/images/admin-image/community-events/' . $event->image)); ?>"
                                    alt="<?php echo e($event->title); ?>">
                                <div class="rare-card-body">
                                    <h5 class="truncate-heading"><?php echo e($event->title); ?></h5>
                                    <p class="truncate-text"><?php echo e($event->short_description); ?></p>
                                    <a href="<?php echo e(url('event/' . $event->slug)); ?>" class="btn-read">Read More</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- Swiper controls -->
                <div class="swiper-pagination"></div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>

            <!-- View More Button -->
            <div class="text-center mt-4">
                <a href="<?php echo e(url('event')); ?>" class="btn btn-primary btn-sm btn-link-view">View All</a>
            </div>
        </div>
    </section>



    
        
            
                
                
                    
                    
                        
                        

                    
                        
                        
                    

                
                
                    
                        
                            
                            
                                
                                    
                                    
                                    
                                    
                                    
                                

                            
                            
                                
                                    
                                    
                                    
                                    
                                    
                                

                            
                            
                                
                                    
                                    
                                    
                                    
                                    
                                

                            
                            
                                
                                    
                                    
                                    
                                    
                                    
                                
                            

                        
                        
                        
                        
                        
                    
                
            
        


    <section class="blog-section">
        <div class="container">
            <div class="text-center">
                <h2>Latest Health Blogs & Medical Articles</h2>
                <p>Stay updated with the latest gynecology, IVF, maternity, and pediatric health blogs from Sunrise
                    Hospital, South Delhi. Expert insights, tips, and innovative treatment updates to guide patients in
                    making informed healthcare decisions.</p>
            </div>
            <div class="swiper myBlogSwiper">
                <div class="swiper-wrapper">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <div class="blog-card">
                                <div class="blog-image">
                                    <img src="<?php echo e(asset('admin-assets/images/admin-image/blogs/' . $blog->image)); ?>"
                                        alt="<?php echo e($blog->title); ?>" />
                                </div>
                                <div class="blog-content">
                                    <!-- Dynamic URL using slug -->
                                    <a href="<?php echo e(route('blog-detail', $blog->slug)); ?>">
                                        <h3 class="blog-title"><?php echo e($blog->title); ?></h3>
                                    </a>
                                    <p class="blog-excerpt"><?php echo e($blog->short_description); ?></p>
                                    <div class="blog-meta">
                                        <span class="author"><?php echo e($blog->author); ?></span>
                                        <div class="meta-info">
                                            <span
                                                class="date"><?php echo e(\Carbon\Carbon::parse($blog->published_date)->format('M d, Y')); ?></span>
                                            |
                                            <span class="read-time">7 min read</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- Swiper controls -->
                <div class="swiper-pagination"></div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>
            <!-- View All Button -->
            <div class="text-center mt-4">
                <a href="<?php echo e(url('blog-list')); ?>" class="btn btn-primary btn-sm btn-link-view">View All</a>
            </div>
        </div>
    </section>

    <!-- Video Testimonials Section -->
    <section class="testimonial-slider">
        <div class="container">
            <div class="text-center">
                <h2>Video Testimonials – Patient Experiences at Sunrise Hospital
                </h2>
                <p>
                    Hear directly from our patients about their experiences at Sunrise Hospital, South Delhi. Watch real
                    stories of successful gynecology, IVF, maternity, and minimally invasive treatments, showcasing our
                    commitment to compassionate care, expertise, and exceptional outcomes. Our video testimonials help you
                    make informed decisions and trust our world-class healthcare services.
                </p>
            </div>
            <div class="swiper TestimonialSwiper">
                <div class="swiper-wrapper">
                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <div class="video-card">
                                <iframe src="<?php echo e(asset('admin-assets/images/admin-image/video-testimonials/' . $video->video)); ?>"
                                    title="<?php echo e($video->title ?? 'Video Testimonial'); ?>" allowfullscreen></iframe>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Swiper Pagination + Navigation -->
                <div class="swiper-pagination"></div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>

            <div class="text-center mt-4">
                <a href="<?php echo e(url('video-testimonial')); ?>" class="btn btn-primary btn-sm btn-link-view">View All</a>
            </div>
        </div>
    </section>

    <section class="faq-section">
        <div class="container">
            <div class="row align-items-center">
                <!-- FAQ Left -->
                <div class="col-lg-7">
                    <h2>Frequently Asked Questions (FAQs)</h2>
                    <p>It is a long established fact that a reader will be distracted by the readable content of a page when
                        looking at its layout.</p>

                    <div class="accordion" id="faqAccordion">
                        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading<?php echo e($key); ?>">
                                    <button class="accordion-button <?php echo e($key != 0 ? 'collapsed' : ''); ?>" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($key); ?>">
                                        <?php echo e($faq->question); ?>

                                    </button>
                                </h2>
                                <div id="collapse<?php echo e($key); ?>" class="accordion-collapse collapse <?php echo e($key == 0 ? 'show' : ''); ?>"
                                    data-bs-parent="#faqAccordion">
                                    <div class="accordion-body">
                                        <?php echo $faq->answer; ?>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <!-- Right Image + Contact -->
                <div class="col-lg-5">
                    <div class="appointment-wrapper">
                        <img src="https://www.sunrisehospitals.in/wp-content/uploads/2024/03/IMG-20240311-WA0137.jpg"
                            alt="Doctor" class="img-fluid faq-img">
                        <div class="contact-box">
                            <div class="d-flex align-items-center">
                                <i class="fa-solid fa-phone"></i>
                                <div>
                                    <small>Contact us</small><br>
                                    <strong>+91 9800001900</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-center mt-4">
                <a href="<?php echo e(url('faq')); ?>" class="btn btn-primary btn-sm btn-link-view">View All</a>
            </div>
        </div>
    </section>

    
        
            
                
                
                    
                        
                        
                            
                                
                                
                                    
                                    

                                
                                
                                    
                                    

                                
                                
                                    
                                    

                                
                                
                                    
                                    

                                
                                
                                    
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                    
                                
                                
                                    
                                    

                                
                                
                                    
                                        
                                        
                                        
                                        
                                        
                                        
                                            
                                            
                                        
                                    
                                
                                
                                    
                                        
                                        
                                    
                                
                            
                        
                    

                
                
                    
                        
                            
                        
                    
                
            
        

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        var swiper = new Swiper(".myEventSwiper", {
            slidesPerView: 3,
            spaceBetween: 30,
            loop: true,
            autoplay: {
                delay: 4000,
                disableOnInteraction: false,
            },
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
            },
            breakpoints: {
                0: {
                    slidesPerView: 1
                },
                768: {
                    slidesPerView: 2
                },
                1200: {
                    slidesPerView: 3
                },
            },
        });
    </script>

    <script>
        var swiper = new Swiper(".PatientTestimonialSwiper", {
            slidesPerView: 1,
            spaceBetween: 30,
            loop: true,
            autoplay: {
                delay: 3500,
                disableOnInteraction: false,
            },
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
            },
            breakpoints: {
                992: { slidesPerView: 3 }
            }
        });

        function bindInstagramIframes() {
            document.querySelectorAll("iframe.instagram-media").forEach(function (iframe) {
                if (iframe.dataset.binded) return;
                iframe.dataset.binded = "true";

                // जब iframe पर click/focus होगा → autoplay stop
                iframe.addEventListener("mouseenter", function () {
                    swiper.autoplay.stop();
                });
                iframe.addEventListener("click", function () {
                    swiper.autoplay.stop();
                });
            });
        }

        // Load के बाद Instagram embed inject होते हैं → थोड़ी देर बाद bind करो
        window.addEventListener("load", function () {
            setTimeout(bindInstagramIframes, 2000);
        });

        // User वापस पेज focus करे → autoplay resume
        window.addEventListener("focus", function () {
            swiper.autoplay.start();
        });
    </script>
    <!-- Instagram embed JS -->
    <script async src="//www.instagram.com/embed.js"></script>

    <script>
        // Generate random captcha
        function generateCaptcha() {
            const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            let captcha = "";
            for (let i = 0; i < 5; i++) {
                captcha += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            document.getElementById("captcha").innerText = captcha;
            document.getElementById("captcha-input").value = "";
        }
        window.onload = generateCaptcha;

        document.addEventListener("DOMContentLoaded", function () {
            // Truncate paragraph text to 14 words
            document.querySelectorAll(".truncate-text").forEach(function (el) {
                let words = el.innerText.trim().split(" ");
                if (words.length > 10) {
                    el.innerText = words.slice(0, 10).join(" ") + "...";
                }
            });
        });

        document.addEventListener("DOMContentLoaded", function () {
            const excerpts = document.querySelectorAll(".blog-excerpt");
            excerpts.forEach(function (excerpt) {
                let text = excerpt.innerText.trim();
                let words = text.split(" ");

                if (words.length > 12) {
                    let shortText = words.slice(0, 12).join(" ") + "...";
                    excerpt.innerText = shortText;
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sunrise(11-10-2025_\resources\views/pages/index.blade.php ENDPATH**/ ?>