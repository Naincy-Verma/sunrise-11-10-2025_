

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="card shadow-sm">
    <div class="card-header d-flex justify-content-between align-items-center">
      <h4 class="card-title mb-0">Quick Enquiry Details</h4>
      <a href="<?php echo e(route('admin.quick-enquiries.index')); ?>" class="btn btn-primary btn-sm">
        <i class="fas fa-arrow-left"></i> Back
      </a>
    </div>

    <div class="card-body">
      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="fw-bold">Name:</label>
          <p class="text-muted"><?php echo e($enquiry->name); ?></p>
        </div>

        <div class="col-md-6 mb-3">
          <label class="fw-bold">Mobile Number:</label>
          <p class="text-muted"><?php echo e($enquiry->mobile_number); ?></p>
        </div>

        <div class="col-md-6 mb-3">
          <label class="fw-bold">Preferred Time Slot:</label>
          <p class="text-muted">
            <?php if($enquiry->timeSlot): ?>
              <?php echo e(\Carbon\Carbon::parse($enquiry->timeSlot->start_time)->format('g:i A')); ?>

              -
              <?php echo e(\Carbon\Carbon::parse($enquiry->timeSlot->end_time)->format('g:i A')); ?>

            <?php else: ?>
              N/A
            <?php endif; ?>
          </p>
        </div>

        <div class="col-md-6 mb-3">
          <label class="fw-bold">Status:</label>
          <p class="text-muted">
            <?php echo e($enquiry->timeSlot ? ucfirst($enquiry->timeSlot->status) : 'N/A'); ?>

          </p>
        </div>

        <div class="col-md-6 mb-3">
          <label class="fw-bold">Created At:</label>
          <p class="text-muted"><?php echo e($enquiry->created_at->format('d M Y, h:i A')); ?></p>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sunrise(11-10-2025_\resources\views/admin/pages/quick_enquiry/show.blade.php ENDPATH**/ ?>