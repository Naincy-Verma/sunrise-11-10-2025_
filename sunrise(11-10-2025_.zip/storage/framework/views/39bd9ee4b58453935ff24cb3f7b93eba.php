

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>Add Gallery Images</h4>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Upload Gallery Images for Community Events</h4>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('community-gallery.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
               <input type="hidden" name="community_event_id" value="<?php echo e($event_id); ?>">
                <div class="form-group mt-3">
                    <label>Gallery Images <span class="text-danger">*</span></label>
                    <input type="file" name="images[]" class="form-control" multiple accept="image/*">
                </div>

                <div class="form-group mt-3">
                    <label>Caption (optional)</label>
                    <input type="text" name="caption" class="form-control" placeholder="Enter caption for images">
                </div>

                <button type="submit" class="btn btn-primary mt-3">Upload Gallery</button>
                <a href="<?php echo e(route('community-gallery.index')); ?>" class="btn btn-light mt-3">Cancel</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sunrise(11-10-2025_\resources\views/admin/pages/community_events/gallery/create.blade.php ENDPATH**/ ?>