

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
      <h4 class="card-title mb-0">Appointments</h4>
      <div>
        <a href="<?php echo e(route('admin.appointments.index')); ?>" class="btn btn-secondary btn-sm <?php echo e(!$status ? 'active' : ''); ?>">
          All (<?php echo e($pendingCount + $confirmedCount + $cancelledCount); ?>)
        </a>
        <a href="<?php echo e(route('admin.appointments.index', ['status' => 'pending'])); ?>" 
           class="btn btn-warning btn-sm text-white<?php echo e($status === 'pending' ? 'active' : ''); ?>">
          Pending (<?php echo e($pendingCount); ?>)
        </a>
        <a href="<?php echo e(route('admin.appointments.index', ['status' => 'confirmed'])); ?>" 
           class="btn btn-success btn-sm <?php echo e($status === 'confirmed' ? 'active' : ''); ?>">
          Confirmed (<?php echo e($confirmedCount); ?>)
        </a>
        <a href="<?php echo e(route('admin.appointments.index', ['status' => 'cancelled'])); ?>" 
           class="btn btn-danger btn-sm text-white<?php echo e($status === 'cancelled' ? 'active' : ''); ?>">
          Cancelled (<?php echo e($cancelledCount); ?>)
        </a>
      </div>
    </div>

      <div class="table-responsive">
        <table class="table table-bordered table-striped align-middle">
          <thead class="table-dark">
            <tr>
              <th>#</th>
              <th>Patient</th>
              <th>Email</th>
              <th>Mobile</th>
              <th>Doctor</th>
              <th>Date</th>
              <th>Status</th>
              <th>Source</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($index + 1); ?></td>
              <td><?php echo e($appointment->title); ?> <?php echo e($appointment->first_name); ?> <?php echo e($appointment->last_name); ?></td>
              <td><?php echo e($appointment->email); ?></td>
              <td><?php echo e($appointment->mobile_no); ?></td>
              <td><?php echo e($appointment->doctor->name ?? 'N/A'); ?></td>
              <td><?php echo e(\Carbon\Carbon::parse($appointment->appointment_date)->format('d M Y')); ?></td>
              <td>
                <?php if($appointment->status === 'pending'): ?>
                  <span class="badge bg-warning text-white">Pending</span>
                <?php elseif($appointment->status === 'confirmed'): ?>
                  <span class="badge bg-success text-white">Confirmed</span>
                <?php else: ?>
                  <span class="badge bg-danger text-white">Cancelled</span>
                <?php endif; ?>
              </td>
              <td><?php echo e($appointment->source); ?></td>
              <td>
                 <!-- View Button -->
                <a href="<?php echo e(route('admin.appointments.show', $appointment->id)); ?>" class="btn btn-info btn-sm" title="View">
                  <i class="fas fa-eye"></i>
                </a>
                <a href="<?php echo e(route('admin.appointments.edit', $appointment->id)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></a>
                <form action="<?php echo e(route('admin.appointments.destroy', $appointment->id)); ?>" method="POST" class="d-inline delete-form">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="button" class="btn btn-danger btn-sm delete-btn" data-title="<?php echo e($appointment->first_name); ?>">
                    <i class="fas fa-trash-alt"></i>
                  </button>
                </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="8" class="text-center text-muted">No appointments found.</td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('.delete-btn').forEach(button => {
    button.addEventListener('click', function() {
      const form = this.closest('.delete-form');
      const title = this.getAttribute('data-title');

      Swal.fire({
        title: 'Are you sure?',
        text: `You are about to delete the appointment for "${title}".`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'Cancel'
      }).then(result => {
        if (result.isConfirmed) form.submit();
      });
    });
  });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sunrise(11-10-2025_\resources\views/admin/pages/book-appointment/appointment/index.blade.php ENDPATH**/ ?>