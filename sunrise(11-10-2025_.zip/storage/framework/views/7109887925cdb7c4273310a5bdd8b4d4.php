<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-4">
    <div class="card shadow">

        <!-- Header -->
        <div class="card-header bg-primary text-white">
            <h3 class="mb-0"><?php echo e($doctor->name); ?></h3>
        </div>

        <!-- Card Body -->
        <div class="card-body">

            <!-- 🏠 Homepage Section -->
            <h5 class="border-bottom pb-2 mb-4 text-primary fw-bold">
                Homepage Section
            </h5>

            <div class="row mb-3">
                <div class="col-md-6"><strong>Designation:</strong> <?php echo e($doctor->designation); ?></div>
                <div class="col-md-6"><strong>Qualification:</strong> <?php echo e($doctor->qualification); ?></div>
            </div>

            <div class="row mb-3">
                <div class="col-md-6"><strong>Speciality:</strong> <?php echo e($doctor->speciality); ?></div>
                <div class="col-md-6"><strong>Experience:</strong> <?php echo e($doctor->experience); ?></div>
            </div>

            <?php if($doctor->profile_image): ?>
            <div class="row mb-4">
                <div class="col-md-6">
                    <strong>Profile Image:</strong><br>
                    <img src="<?php echo e(asset('admin-assets/images/admin-image/doctors/' . $doctor->profile_image)); ?>" 
                         class="img-thumbnail mt-2" style="width:160px; height:160px; object-fit:cover; border-radius:10px;">
                </div>
            </div>
            <?php endif; ?>

            <div class="mb-4">
                <strong>Short Description:</strong>
                <div class="p-3 bg-light border rounded">
                    <?php echo $doctor->description; ?>

                </div>
            </div>

            <!-- ✅ Profile & Appointment URLs -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <strong>Profile URL:</strong><br>
                    <?php if($doctor->profile_url): ?>
                        <a href="<?php echo e($doctor->profile_url); ?>" target="_blank"><?php echo e($doctor->profile_url); ?></a>
                    <?php else: ?>
                        <span class="text-muted">Not available</span>
                    <?php endif; ?>
                </div>
                <div class="col-md-6">
                    <strong>Appointment URL:</strong><br>
                    <?php if($doctor->appointment_url): ?>
                        <a href="<?php echo e($doctor->appointment_url); ?>" target="_blank"><?php echo e($doctor->appointment_url); ?></a>
                    <?php else: ?>
                        <span class="text-muted">Not available</span>
                    <?php endif; ?>
                </div>
            </div>

            <hr class="my-4">

            <!-- 📄 Detail Page Section -->
            <h5 class="border-bottom pb-2 mb-4 text-primary fw-bold">
                Detail Page Section
            </h5>

            <div class="mb-4">
                <strong>Brief Profile Heading:</strong> <?php echo e($doctor->brief_profile_heading); ?><br>
                <strong>Brief Profile Description:</strong>
                <div class="p-3 bg-light border rounded mt-2">
                    <?php echo $doctor->brief_profile_description; ?>

                </div>
            </div>

            <div class="mb-4">
                <strong>Metrics:</strong>
                <div class="p-3 bg-light border rounded">
                    <?php echo $doctor->metrics; ?>

                </div>
            </div>

            <div class="mb-4">
                <strong>Notable Records:</strong>
                <div class="p-3 bg-light border rounded">
                    <?php echo $doctor->notable_records; ?>

                </div>
            </div>

            <div class="mb-4">
                <strong>Professional Achievements:</strong>
                <div class="p-3 bg-light border rounded">
                    <p><strong>Heading:</strong> <?php echo e($doctor->professional_heading); ?></p>
                    <p><strong>Subheading:</strong> <?php echo e($doctor->professional_subheading); ?></p>
                    <p><?php echo $doctor->professional_description; ?></p>
                    <p><strong>Training Record:</strong> <?php echo $doctor->training_record; ?></p>
                </div>
            </div>

            <div class="mb-4">
                <strong>Specialized Procedures:</strong>
                <div class="p-3 bg-light border rounded">
                    <p><strong>Heading:</strong> <?php echo e($doctor->specialized_heading); ?></p>
                    <p><strong>Subheading:</strong> <?php echo e($doctor->specialized_subheading); ?></p>
                    <p><strong>Title:</strong> <?php echo e($doctor->specialized_title); ?></p>
                    <p><?php echo $doctor->specialized_description; ?></p>
                </div>
            </div>

            <div class="mb-4">
                <strong>Areas of Specialization:</strong>
                <div class="p-3 bg-light border rounded">
                    <?php echo $doctor->areas_of_specialization; ?>

                </div>
            </div>

            <div class="mb-4">
                <strong>Professional Contributions:</strong>
                <div class="p-3 bg-light border rounded">
                    <p><strong>Heading:</strong> <?php echo e($doctor->contributions_heading); ?></p>
                    <p><?php echo $doctor->contributions_description; ?></p>
                    <p><strong>Latest Achievement:</strong> <?php echo e($doctor->latest_achievement); ?></p>
                </div>
            </div>

        </div>

        <!-- Footer Buttons -->
        <div class="card-footer text-end">
            <a href="<?php echo e(route('doctors.index')); ?>" class="btn btn-secondary me-2">Back</a>
            <a href="<?php echo e(route('doctors.edit', $doctor->id)); ?>" class="btn btn-primary">Edit</a>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sunrise(11-10-2025_\resources\views/admin/pages/doctor/show.blade.php ENDPATH**/ ?>