<?php $__env->startSection('content'); ?>
<style>
.section-title {
    font-size: 18px;
    font-weight: 600;
    color: #2f855a;
    border-left: 5px solid #7aa93c;
    padding-left: 12px;
    margin-top: 35px;
    margin-bottom: 15px;
    display: flex;
    align-items: center;
}
.section-title i {
    margin-right: 8px;
}
.info-card {
    background: #f9fafb;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 25px;
}
.info-card p {
    margin-bottom: 8px;
}
.list-style {
    background: #f8fff5;
    border: 1px solid #d1fadf;
    padding: 12px 20px;
    border-radius: 10px;
}
.img-preview {
    border-radius: 10px;
    border: 1px solid #e2e8f0;
    max-width: 250px;
}
</style>

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-lg-11">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                    <h4 class="mb-0 text-uppercase"><i class="fas fa-user-md me-2"></i><?php echo e($doctor->name); ?></h4>
                    <a href="<?php echo e(route('admin.doctors.index')); ?>" class="btn btn-light btn-sm">
                        <i class="fas fa-arrow-left me-1"></i> Back
                    </a>
                </div>

                <div class="card-body">

                    <!-- ================= Profile Information ================= -->
                    <h5 class="section-title"><i class="fas fa-id-card"></i> Profile Information</h5>
                    <div class="info-card">
                        <div class="row align-items-center">
                            <div class="col-md-3 text-center">
                                <?php if($doctor->profile_image): ?>
                                    <img src="<?php echo e(asset('admin-assets/images/admin-image/doctors/' . $doctor->profile_image)); ?>" 
                                         class="img-fluid img-preview mb-2" alt="<?php echo e($doctor->name); ?>">
                                <?php else: ?>
                                    <div class="border p-4 bg-light text-muted rounded mb-3">No Image</div>
                                <?php endif; ?>
                            </div>

                            <div class="col-md-9">
                                 <p><strong>Name:</strong> <?php echo e($doctor->name ?? '—'); ?></p>
                                <p><strong>Speciality:</strong> <?php echo e($doctor->speciality->title ?? '—'); ?></p>
                                <p><strong>Designation:</strong> <?php echo e($doctor->designation ?? '—'); ?></p>
                                <p><strong>Experience:</strong> <?php echo e($doctor->experience ?? '—'); ?></p>
                                <p><strong>Qualification:</strong> <?php echo e($doctor->qualification ?? '—'); ?></p>
                                <p><strong>Short Description:</strong> <?php echo e($doctor->description ?? '—'); ?></p>
                                <p><strong>Profile URL:</strong> <?php echo e($doctor->profile_url ?? '—'); ?></p>
                                <?php if($doctor->appointment_url): ?>
                                    <p><strong>Appointment URL:</strong> 
                                        <a href="<?php echo e($doctor->appointment_url); ?>" target="_blank" class="text-success">
                                            <?php echo e($doctor->appointment_url); ?>

                                        </a>
                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- ================= Brief Profile Section ================= -->
                    <h5 class="section-title"><i class="fas fa-user-circle"></i> Brief Profile</h5>
                    <div class="info-card">
                        <p><strong>Heading:</strong> <?php echo e($doctor->brief_profile_heading ?? '—'); ?></p>
                        <p><strong>Description:</strong></p>
                        <div><?php echo $doctor->brief_profile_description ?? '—'; ?></div>

                        <?php if($doctor->brief_profile_image): ?>
                            <p class="mt-3"><strong>Image:</strong></p>
                            <img src="<?php echo e(asset('admin-assets/images/admin-image/doctors/' . $doctor->brief_profile_image)); ?>" 
                                 class="img-fluid img-preview mb-3" alt="Brief Profile Image">
                        <?php endif; ?>

                        <?php if($doctor->brief_notable_records): ?>
                            <h6 class="mt-3 text-success fw-bold">Notable Records</h6>
                            <div><?php echo $doctor->brief_notable_records; ?></div>
                        <?php endif; ?>

                       <?php if(is_array($doctor->brief_metrics)): ?>
                            <h6 class="mt-3 text-success fw-bold">Metrics</h6>
                            <ul class="list-style">
                                <?php $__currentLoopData = $doctor->brief_metrics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><strong><?php echo e($metric['label'] ?? ''); ?>:</strong> <?php echo e($metric['value'] ?? ''); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>

                    <!-- ================= Professional Section ================= -->
                    <h5 class="section-title"><i class="fas fa-trophy"></i> Professional Achievements</h5>
                    <div class="info-card">
                        <p><strong>Heading:</strong> <?php echo e($doctor->professional_heading ?? '—'); ?></p>
                        <?php if(is_array($doctor->professional_description)): ?>
                         <h6 class="mt-3 text-success fw-bold"> Professional Description</h6>
                            <ul class="list-style">
                                <?php $__currentLoopData = $doctor->professional_description; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><strong><?php echo e($desc['label'] ?? ''); ?>:</strong> <?php echo e($desc['value'] ?? ''); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <p>—</p>
                        <?php endif; ?>
                    </div>

                    <!-- ================= Training Section ================= -->
                    <h5 class="section-title"><i class="fas fa-graduation-cap"></i> Training Details</h5>
                    <div class="info-card">
                        <p><strong>Heading:</strong> <?php echo e($doctor->training_heading ?? '—'); ?></p>
                            <?php if(is_array($doctor->training_description)): ?>
                             <h6 class="mt-3 text-success fw-bold"> Training Description</h6>
                                <ul class="list-style">
                                    <?php $__currentLoopData = $doctor->training_description; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><strong><?php echo e($desc['label'] ?? ''); ?>:</strong> <?php echo e($desc['value'] ?? ''); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php else: ?>
                            <p>—</p>
                        <?php endif; ?>
                        <?php if($doctor->training_record): ?>
                            <h6 class="mt-3 text-success fw-bold">Training Record</h6>
                            <div><?php echo $doctor->training_record; ?></div>
                        <?php endif; ?>
                    </div>

                    <!-- ================= Specialized Section ================= -->
                    <h5 class="section-title"><i class="fas fa-stethoscope"></i> Specialized Details</h5>
                    <div class="info-card">
                        <p><strong>Heading:</strong> <?php echo e($doctor->specialized_heading ?? '—'); ?></p>
                        <p><strong>Subheading:</strong> <?php echo e($doctor->specialized_subheading ?? '—'); ?></p>
                        <?php if(is_array($doctor->specialized_description)): ?>
                         <h6 class="mt-3 text-success fw-bold">Specialized Description</h6>
                            <ul class="list-style">
                                <?php $__currentLoopData = $doctor->specialized_description; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><strong><?php echo e($desc['label'] ?? ''); ?>:</strong> <?php echo e($desc['value'] ?? ''); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <p>—</p>
                        <?php endif; ?>
                    </div>

                    <!-- ================= Areas of Specialization ================= -->
                    <h5 class="section-title"><i class="fas fa-briefcase-medical"></i> Areas of Specialization</h5>
                    <div class="info-card">
                        <p><strong>Heading:</strong> <?php echo e($doctor->area_specialized_heading ?? '—'); ?></p>
                        <?php if(!empty($doctor->areas_of_specialization)): ?>
                         <h6 class="mt-3 text-success fw-bold"> Area of Specialization Description</h6>
                            <ul class="list-style">
                                <?php $__currentLoopData = $doctor->areas_of_specialization; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($area); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <p>—</p>
                        <?php endif; ?>
                    </div>

                    <!-- ================= Contributions Section ================= -->
                    <h5 class="section-title"><i class="fas fa-hand-holding-heart"></i> Contributions</h5>
                    <div class="info-card">
                        <p><strong>Heading:</strong> <?php echo e($doctor->contributions_heading ?? '—'); ?></p>
                         <h6 class="mt-3 text-success fw-bold"> Contribution Description</h6>
                        <div><?php echo $doctor->contributions_description ?? '—'; ?></div>
                    </div>

                    <!-- ================= Latest Achievements ================= -->
                    <h5 class="section-title"><i class="fas fa-medal"></i> Latest Achievement</h5>
                    <div class="info-card">
                        <div><?php echo $doctor->latest_achievement ?? '—'; ?></div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sunrise(11-10-2025_\resources\views/admin/pages/doctor/show.blade.php ENDPATH**/ ?>