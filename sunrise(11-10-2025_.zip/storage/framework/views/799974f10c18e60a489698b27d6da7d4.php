

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

  <div class="card mb-4">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
      <h4 class="mb-0"><?php echo e($education->heading); ?></h4>
      <a href="<?php echo e(route('admin.patient-education.index')); ?>" class="btn btn-light btn-sm">Back</a>
    </div>

    <div class="card-body">
        <?php if($allEducations->count()): ?>
            <div class="row">
                <?php $__currentLoopData = $allEducations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 mb-3">
                        <div class="p-3 border rounded bg-light"><?php echo e($edu->description); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <p class="text-muted">No descriptions found.</p>
        <?php endif; ?>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sunrise(11-10-2025_\resources\views/admin/pages/patient_education/show.blade.php ENDPATH**/ ?>