

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="card">
    <div class="card-header">
      <h4>Edit Appointment Status</h4>
    </div>

    <div class="card-body">
      <form action="<?php echo e(route('admin.appointments.update', $appointment->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
          <label for="status" class="form-label">Change Status</label>
          <select name="status" id="status" class="form-select" required>
            <option value="pending" <?php echo e($appointment->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
            <option value="confirmed" <?php echo e($appointment->status == 'confirmed' ? 'selected' : ''); ?>>Confirmed</option>
            <option value="cancelled" <?php echo e($appointment->status == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
          </select>
          <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
        <a href="<?php echo e(route('admin.appointments.index')); ?>" class="btn btn-secondary">Back</a>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sunrise(11-10-2025_\resources\views/admin/pages/book-appointment/appointment/edit.blade.php ENDPATH**/ ?>