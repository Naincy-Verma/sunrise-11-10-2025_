<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="card-title mb-0">Doctors List</h4>
                    <a href="<?php echo e(route('admin.doctors.create')); ?>" class="btn btn-primary">Add Doctor</a>
                </div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                        <p class="text-success mb-3"><?php echo e(session('success')); ?></p>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped align-middle">
                            <thead class="table-dark">
                                <tr>
                                    <th>No.</th>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Speciality</th>
                                    <th>Designation</th>
                                    <th>Experience</th>
                                    <th>Qualification</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td>
                                            <?php if($doctor->profile_image): ?>
                                                <img src="<?php echo e(asset('admin-assets/images/admin-image/doctors/' . $doctor->profile_image)); ?>" width="50" class="rounded">
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($doctor->name); ?></td>
                                        <td><?php echo e($doctor->speciality->title ?? '—'); ?></td>
                                        <td><?php echo e($doctor->designation); ?></td>
                                        <td><?php echo e($doctor->experience); ?></td>
                                        <td><?php echo e($doctor->qualification); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('admin.doctors.show', $doctor->id)); ?>" class="btn btn-info btn-sm" title="View">
                                                <i class="fas fa-eye"></i>
                                            </a>

                                            <a href="<?php echo e(route('admin.doctors.edit', $doctor->id)); ?>" class="btn btn-primary btn-sm" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>

                                            <form action="<?php echo e(route('admin.doctors.destroy', $doctor->id)); ?>" method="POST" class="delete-form d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="button" class="btn btn-danger btn-sm delete-btn" data-title="<?php echo e($doctor->name); ?>">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted">No doctors found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function() {
            const form = this.closest('.delete-form');
            const title = this.getAttribute('data-title');

            Swal.fire({
                title: 'Are you sure?',
                text: `You are about to delete "${title}". This action cannot be undone.`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel'
            }).then(result => {
                if (result.isConfirmed) form.submit();
            });
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sunrise(11-10-2025_\resources\views/admin/pages/doctor/index.blade.php ENDPATH**/ ?>