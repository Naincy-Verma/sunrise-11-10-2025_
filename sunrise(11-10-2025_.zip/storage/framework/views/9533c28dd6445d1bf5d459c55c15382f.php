

<?php $__env->startSection('css'); ?>
<style>
    .preview-video {
        width: 480px;
        height: 360px;
        border: 2px solid #ccc;
        border-radius: 10px;
        margin: 15px 0; /* ✅ Added vertical spacing */
    }
    .section-title {
        font-weight: 600;
        font-size: 16px;
        background: #f1f5f9;
        border-left: 4px solid #007bff;
        padding: 10px 15px;
        margin-top: 15px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0">
            <div class="welcome-text">
                <h4>Video Testimonial Details</h4>
            </div>
        </div>
        <div class="col-sm-6 d-flex justify-content-sm-end">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('video_testimonials.index')); ?>">Video Testimonials</a></li>
                <li class="breadcrumb-item active">View Video Testimonial</li>
            </ol>
        </div>
    </div>

    <!-- Testimonial Details -->
    <div class="card">
        <div class="card-header">
            <h4 class="card-title"><?php echo e($video->patient_name); ?></h4>
        </div>
        <div class="card-body">
            <div class="section-title">🧑‍⚕️ Patient Information</div>
            <p><strong>Name:</strong> <?php echo e($video->patient_name); ?></p>
            <p><strong>Title:</strong> <?php echo e($video->title ?? '-'); ?></p>
            <p><strong>Description:</strong> <?php echo e($video->description ?? 'No description provided.'); ?></p>
            

            <?php if($video->video && file_exists(public_path('admin-assets/images/admin-image/video-testimonials/' . $video->video))): ?>
                <div class="section-title">🎬 Video Testimonial</div>
                <?php
                    $ext = pathinfo($video->video, PATHINFO_EXTENSION);
                ?>
                <video class="preview-video" controls>
                    <source src="<?php echo e(asset('admin-assets/images/admin-image/video-testimonials/' . $video->video)); ?>" type="video/<?php echo e($ext); ?>">
                    Your browser does not support the video tag.
                </video>
            <?php else: ?>
                <div class="section-title">🎬 Video Testimonial</div>
                <p class="text-muted">No video uploaded.</p>
            <?php endif; ?>

            <div class="mt-3">
                <a href="<?php echo e(route('video_testimonials.index')); ?>" class="btn btn-light">Back</a>
                <a href="<?php echo e(route('video_testimonials.edit', $video->id)); ?>" class="btn btn-primary">Edit</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\sunrise_backendddd\sunrise_backendddd\resources\views/admin/pages/video_testimonials/show.blade.php ENDPATH**/ ?>