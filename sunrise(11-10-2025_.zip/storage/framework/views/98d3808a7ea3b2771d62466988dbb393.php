

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
      <h4 class="card-title mb-0">Patient Education</h4>
      <a href="<?php echo e(route('admin.patient-education.create')); ?>" class="btn btn-primary">Add Patient Education</a>
    </div>

    <div class="table-responsive mt-3">
      <table class="table table-bordered table-striped align-middle">
        <thead class="table-light">
          <tr>
            <th>No.</th>
            <th>Heading</th>
            <th>Description</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php
              $grouped = $educations->groupBy('heading');
          ?>

          <?php $__empty_1 = true; $__currentLoopData = $grouped; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $heading => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($loop->iteration); ?></td>
              <td><?php echo e($heading); ?></td>
             
               <td>
                  <?php echo e(Str::limit(implode(', ', $items->first()->description ?? []), 100)); ?>

              </td>
              <td>
                <!-- Show Page -->
                <a href="<?php echo e(route('admin.patient-education.show', $items->first()->id)); ?>" class="btn btn-secondary btn-sm" title="View">
                  <i class="fas fa-eye"></i>
                </a>

                <!-- Edit -->
                <a href="<?php echo e(route('admin.patient-education.edit', $items->first()->id)); ?>" class="btn btn-info btn-sm" title="Edit">
                  <i class="fas fa-edit"></i>
                </a>

                <!-- Delete -->
                <form action="<?php echo e(route('admin.patient-education.destroy', $items->first()->id)); ?>" method="POST" class="d-inline delete-form">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="button" class="btn btn-danger btn-sm delete-btn" data-title="<?php echo e($heading); ?>">
                    <i class="fas fa-trash-alt"></i>
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="4" class="text-center text-muted">No Patient Education records found.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
  const deleteButtons = document.querySelectorAll('.delete-btn');
  deleteButtons.forEach(button => {
    button.addEventListener('click', function() {
      const form = this.closest('.delete-form');
      const title = this.getAttribute('data-title');
      Swal.fire({
        title: 'Are you sure?',
        text: `You are about to delete "${title}"! This action cannot be undone.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'Cancel'
      }).then((result) => {
        if (result.isConfirmed) {
          form.submit();
        }
      });
    });
  });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sunrise(11-10-2025_\resources\views/admin/pages/patient_education/index.blade.php ENDPATH**/ ?>