

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="card">
    <div class="card-header">
      <h4>Appointment Details</h4>
    </div>
    <div class="card-body">
      <table class="table table-bordered">
        <tr>
          <th>Full Name</th>
          <td><?php echo e($appointment->full_name); ?></td>
        </tr>
        <tr>
          <th>Title</th>
          <td><?php echo e($appointment->title); ?></td>
        </tr>
        <tr>
          <th>Middle Name</th>
          <td><?php echo e($appointment->middle_name ?: 'N/A'); ?></td>
        </tr>
        <tr>
          <th>Last Name</th>
          <td><?php echo e($appointment->last_name ?: 'N/A'); ?></td>
        </tr>
        <tr>
          <th>Gender</th>
          <td><?php echo e($appointment->gender); ?></td>
        </tr>
        <tr>
          <th>Date of Birth</th>
          <td><?php echo e($appointment->dob); ?></td>
        </tr>
        <tr>
          <th>Email</th>
          <td><?php echo e($appointment->email); ?></td>
        </tr>
        <tr>
          <th>Mobile</th>
          <td><?php echo e($appointment->mobile_no); ?></td>
        </tr>
        <tr>
          <th>Pin Code</th>
          <td><?php echo e($appointment->pin_code ?: 'N/A'); ?></td>
        </tr>
        <tr>
          <th>Appointment Date</th>
          <td><?php echo e(\Carbon\Carbon::parse($appointment->appointment_date)->format('d M Y')); ?></td>
        </tr>
        <tr>
          <th>Country</th>
          <td><?php echo e($appointment->country->name ?? 'N/A'); ?></td>
        </tr>
        <tr>
          <th>State</th>
          <td><?php echo e($appointment->state->name ?? 'N/A'); ?></td>
        </tr>
        <tr>
          <th>City</th>
          <td><?php echo e($appointment->city->name ?? 'N/A'); ?></td>
        </tr>
        <tr>
          <th>Speciality</th>
          <td><?php echo e($appointment->speciality->title ?? 'N/A'); ?></td>
        </tr>
        <tr>
          <th>Doctor</th>
          <td><?php echo e($appointment->doctor->name ?? 'N/A'); ?></td>
        </tr>
        <tr>
          <th>Time Slot</th>
          <!-- <td><?php echo e($appointment->timeSlot->slot ?? 'N/A'); ?></td> -->
           <td>
            <?php if($appointment->timeSlot): ?>
                <?php echo e(\Carbon\Carbon::parse($appointment->timeSlot->start_time)->format('h:i A')); ?>

                -
                <?php echo e(\Carbon\Carbon::parse($appointment->timeSlot->end_time)->format('h:i A')); ?>

            <?php else: ?>
                N/A
            <?php endif; ?>
        </td>
        </tr>
        <tr>
          <th>Status</th>
          <td>
            <span class="badge bg-<?php echo e($appointment->status === 'pending' ? 'warning' : ($appointment->status === 'confirmed' ? 'success' : 'danger')); ?>">
              <?php echo e(ucfirst($appointment->status)); ?>

            </span>
          </td>
        </tr>
        <tr>
          <th>Source</th>
          <td><?php echo e($appointment->source); ?></td>
        </tr>
      </table>

      <a href="<?php echo e(route('admin.appointments.index')); ?>" class="btn btn-secondary mt-3">Back</a>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sunrise(11-10-2025_\resources\views/admin/pages/book-appointment/appointment/show.blade.php ENDPATH**/ ?>