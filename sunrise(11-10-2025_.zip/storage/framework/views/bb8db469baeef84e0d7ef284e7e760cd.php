

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="card">
    <div class="card-header">
      <h4 class="card-title"><?php echo e($faq->question); ?></h4>
    </div>
    <div class="card-body">
      <p><strong>Answer:</strong></p>
      <p><?php echo $faq->answer; ?></p>

      <?php if($faq->image && file_exists(public_path('admin-assets/images/admin-image/faqs/' . $faq->image))): ?>
        <div class="mt-3">
          <img src="<?php echo e(asset('admin-assets/images/admin-image/faqs/' . $faq->image)); ?>" width="250" class="rounded border">
        </div>
      <?php endif; ?>

      <div class="mt-3">
        <a href="<?php echo e(route('faqs.index')); ?>" class="btn btn-light">Back</a>
        <a href="<?php echo e(route('faqs.edit', $faq->id)); ?>" class="btn btn-primary">Edit</a>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sunrise(11-10-2025_\resources\views/admin/pages/faqs/show.blade.php ENDPATH**/ ?>