

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="card">
    <div class="card-header d-flex justify-content-between">
      <h4 class="card-title mb-0">FAQs</h4>
      <a href="<?php echo e(route('faqs.create')); ?>" class="btn btn-primary">Add FAQ</a>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th>No.</th>
              <th>Question</th>
              <th>Answer</th>
              <th>Image</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($index + 1); ?></td>
              <td><?php echo e($faq->question); ?></td>
              <td><?php echo \Illuminate\Support\Str::limit(strip_tags($faq->answer), 50); ?></td>
              <td>
                <?php if($faq->image && file_exists(public_path('admin-assets/images/admin-image/faqs/' . $faq->image))): ?>
                  <img src="<?php echo e(asset('admin-assets/images/admin-image/faqs/' . $faq->image)); ?>" width="80" class="rounded">
                <?php else: ?>
                  <span class="text-muted">No Image</span>
                <?php endif; ?>
              </td>
              <td>
                <a href="<?php echo e(route('faqs.show', $faq->id)); ?>" class="btn btn-secondary btn-sm"><i class="fas fa-eye"></i></a>
                <a href="<?php echo e(route('faqs.edit', $faq->id)); ?>" class="btn btn-info btn-sm"><i class="fas fa-edit"></i></a>
              <form action="<?php echo e(route('faqs.destroy', $faq->id)); ?>" method="POST" style="display:inline;" class="delete-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="button" class="btn btn-danger btn-sm delete-btn" data-title="<?php echo e($faq->question); ?>">
            <i class="fas fa-trash-alt"></i>
        </button>
    </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="5" class="text-center text-muted">No FAQs found.</td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const deleteButtons = document.querySelectorAll('.delete-btn');

    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const form = this.closest('.delete-form');
            const title = this.getAttribute('data-title');

            Swal.fire({
                title: 'Are you sure?',
                text: `You are about to delete "${title}"! This action cannot be undone.`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sunrise(11-10-2025_\resources\views/admin/pages/faqs/index.blade.php ENDPATH**/ ?>