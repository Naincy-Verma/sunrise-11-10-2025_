

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="card">
    <div class="card-header">
      <h4 class="card-title">Edit FAQ</h4>
    </div>
    <div class="card-body">
      <form action="<?php echo e(route('faqs.update', $faq->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
          <label>Question <span class="text-danger">*</span></label>
          <input type="text" name="question" value="<?php echo e(old('question', $faq->question)); ?>" class="form-control" required>
        </div>

        <div class="form-group">
          <label>Answer <span class="text-danger">*</span></label>
          <textarea name="answer" class="form-control" rows="5" required><?php echo e(old('answer', $faq->answer)); ?></textarea>
        </div>

        <div class="form-group">
          <label>FAQ Image (Optional)</label>
          <input type="file" name="image" class="form-control" accept=".jpg,.jpeg,.png,.webp">
          <?php if($faq->image): ?>
            <div class="mt-2">
              <img src="<?php echo e(asset('admin-assets/images/admin-image/faqs/' . $faq->image)); ?>" width="100" class="rounded">
            </div>
          <?php endif; ?>
        </div>

        <div class="text-end mt-3">
          <button type="submit" class="btn btn-primary">Update</button>
          <a href="<?php echo e(route('faqs.index')); ?>" class="btn btn-light">Cancel</a>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\sunrise(11-10-2025_\resources\views/admin/pages/faqs/edit.blade.php ENDPATH**/ ?>